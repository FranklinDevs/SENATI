<?php
$connect = new PDO("mysql:host=localhost;dbname=angular_bd", "root", "");
?>